package com.example.lostandfoundapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class dbHelper extends SQLiteOpenHelper{
    public static final String DB_Name = "LostFound.db";

    public dbHelper(Context context){
        super(context, DB_Name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE adverts (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "type TEXT," + "name TEXT," +
                "phone TEXT," + "category TEXT," +
                "description TEXT," + "location TEXT," +
                "imagePath TEXT," + "date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS adverts");
        onCreate(db);
    }

    public boolean insertAdvert(String type, String name, String phone, String category, String description, String location, String imagePath, String date){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("type", type);
        cv.put("name", name);
        cv.put("phone", phone);
        cv.put("category", category);
        cv.put("description", description);
        cv.put("location", location);
        cv.put("imagePath", imagePath);
        cv.put("date", date);

        long result = db.insert("adverts", null, cv);
        return result != -1;
    }

    public Cursor getAllAdverts(){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM adverts", null);
    }

    public Cursor searchByCategory(String category){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM adverts WHERE category=?", new String[]{category});
    }

    public void deleteAdvert(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("adverts", "id=?", new String[]{String.valueOf(id)});
    }
}
