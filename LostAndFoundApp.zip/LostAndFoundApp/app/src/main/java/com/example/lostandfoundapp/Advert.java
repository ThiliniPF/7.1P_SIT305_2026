package com.example.lostandfoundapp;

public class Advert {
    int id;
    String type, name, phone, category, description, location, imagePath, date;

    public Advert(int id, String type, String name, String phone, String category, String description, String location, String imagePath, String date) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.phone = phone;
        this.category = category;
        this.description = description;
        this.location = location;
        this.imagePath = imagePath;
        this.date = date;
    }

    public int getId() { return id; }
    public String getType() { return type; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public String getLocation() { return location; }
    public String getImagePath() { return imagePath; }
    public String getDate() { return date; }
}