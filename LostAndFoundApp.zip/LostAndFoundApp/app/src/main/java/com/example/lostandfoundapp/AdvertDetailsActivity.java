package com.example.lostandfoundapp;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AdvertDetailsActivity extends AppCompatActivity{
    TextView txtType, txtName, txtPhone, txtCategory, txtDescription, txtLocation, txtDate;
    ImageView imageView;
    Button btnDelete;
    dbHelper databaseHelper;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advert_details);

        txtType = findViewById(R.id.txtType);
        txtName = findViewById(R.id.txtName);
        txtPhone = findViewById(R.id.txtPhone);
        txtCategory = findViewById(R.id.txtCategory);
        txtDescription = findViewById(R.id.txtDescription);
        txtLocation = findViewById(R.id.txtLocation);
        txtDate = findViewById(R.id.txtDate);
        imageView = findViewById(R.id.imageView);
        btnDelete = findViewById(R.id.btnDelete);

        databaseHelper = new dbHelper(this);

        id = getIntent().getIntExtra("id", -1);

        txtType.setText("Type: " + getIntent().getStringExtra("type"));
        txtName.setText("Name: " + getIntent().getStringExtra("name"));
        txtPhone.setText("Phone: " + getIntent().getStringExtra("phone"));
        txtCategory.setText("Category: " + getIntent().getStringExtra("category"));
        txtDescription.setText("Description: " + getIntent().getStringExtra("description"));
        txtLocation.setText("Location: " + getIntent().getStringExtra("location"));
        txtDate.setText("Date: " + getIntent().getStringExtra("date"));

        try{
            imageView.setImageURI(Uri.parse(getIntent().getStringExtra("image")));
        } catch (Exception e) {
            imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        btnDelete.setOnClickListener(v -> {
            if (id != -1) {
                databaseHelper.deleteAdvert(id);
                Toast.makeText(this, "Advert deleted successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}