package com.example.lostandfoundapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android. app.DatePickerDialog;
import android.app.TimePickerDialog;
import java.util.Calendar;
import android.net.Uri;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.text.DateFormat;
import java.util.Date;

public class CreateActivity extends AppCompatActivity {
    RadioButton rbLost, rbFound;
    EditText edtName, edtPhone, edtDescription, edtLocation;
    Spinner spinnerCategory;
    Button btnUpload, btnSave;
    ImageView imageView;
    TextView txtDate;
    Uri imageUri;

    private static  final int PICK_IMAGE = 1;

    String[] categories = { "Electronics", "Pets", "Wallets", "Keys", "Documents", "Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create);

        dbHelper databaseHelper = new dbHelper(this);

        rbLost = findViewById(R.id.rdLost);
        rbFound = findViewById(R.id.rdFound);
        edtName = findViewById(R.id.edtName);
        edtPhone = findViewById(R.id.edtPhone);
        edtDescription = findViewById(R.id.edtDescription);
        edtLocation = findViewById(R.id.edtLocation);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnUpload = findViewById(R.id.btnUpload);
        btnSave = findViewById(R.id.btnSave);
        imageView = findViewById(R.id.imageView);
        txtDate = findViewById(R.id.txtDate);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, categories
        );
        spinnerCategory.setAdapter(adapter);

        final Calendar calendar = Calendar.getInstance();
        txtDate.setOnClickListener(v -> {
            DatePickerDialog datePicker = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                TimePickerDialog timePicker = new TimePickerDialog(this, (timeView, hourOfDay, minute) -> {
                    String selectedDateTime = dayOfMonth + "/" + (month + 1) + "/" + year + " " + hourOfDay + ":" + String.format("%02d", minute);txtDate.setText(selectedDateTime);
                    },
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE), true);
                        timePicker.show();
                    },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH));
            datePicker.show();
        });

        btnUpload.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");

            startActivityForResult(intent, PICK_IMAGE);
        });

        btnSave.setOnClickListener(v -> {
            String type;
            if(rbLost.isChecked()) {
                type = "Lost";
            } else {
                type = "Found";
            }

            String name = edtName.getText().toString();
            String phone = edtPhone.getText().toString();
            String category = spinnerCategory.getSelectedItem().toString();
            String description = edtDescription.getText().toString();
            String location = edtLocation.getText().toString();
            String date = txtDate.getText().toString();

            if(name.isEmpty() || phone.isEmpty() || description.isEmpty() || location.isEmpty() || imageUri == null) {
                Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = databaseHelper.insertAdvert(
                    type, name, phone, category, description, location, imageUri.toString(), date
            );

            if(inserted){
                Toast.makeText(this, "Advert saved successfully", Toast.LENGTH_LONG).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save advert", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }
}