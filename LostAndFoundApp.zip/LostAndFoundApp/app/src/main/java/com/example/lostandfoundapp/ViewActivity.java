package com.example.lostandfoundapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ViewActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    Spinner spinnerSearch;
    ArrayList<Advert> advertList;
    AdvertAdapter adapter;
    dbHelper databaseHelper;
    String[] categories = { "All", "Electronics", "Pets", "Wallets", "Keys", "Documents", "Other" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        recyclerView = findViewById(R.id.recyclerView);
        spinnerSearch = findViewById(R.id.spinnerSearch);

        databaseHelper = new dbHelper(this);
        advertList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new AdvertAdapter(this, advertList);
        recyclerView.setAdapter(adapter);

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories);
        spinnerSearch.setAdapter(spinnerAdapter);
        loadAllAdverts();

        spinnerSearch.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id){
                String selectedCategory = categories[position];

                if(selectedCategory.equals("All")) {
                    loadAllAdverts();
                } else {
                    searchCategory(selectedCategory);
                }
            }
            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private void loadAllAdverts(){
        advertList.clear();
        Cursor cursor = databaseHelper.getAllAdverts();

        while(cursor.moveToNext()){
            Advert advert = new Advert(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6),
                    cursor.getString(7),
                    cursor.getString(8)
            );
            advertList.add(advert);
        }
        adapter.notifyDataSetChanged();
    }

    private void searchCategory(String category){
        advertList.clear();
        Cursor cursor = databaseHelper.searchByCategory(category);

        while(cursor.moveToNext()){
            Advert advert = new Advert(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6),
                    cursor.getString(7),
                    cursor.getString(8)
            );
            advertList.add(advert);
        }
        adapter.notifyDataSetChanged();
    }
}