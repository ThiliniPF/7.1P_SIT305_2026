package com.example.lostandfoundapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AdvertAdapter extends RecyclerView.Adapter<AdvertAdapter.ViewHolder> {
    Context context;
    ArrayList<Advert> advertList;

    public AdvertAdapter(Context context, ArrayList<Advert> advertList) {
        this.context = context;
        this.advertList = advertList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(context).inflate(R.layout.advert_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position){
        Advert advert = advertList.get(position);
        holder.txtType.setText(advert.getType());
        holder.txtCategory.setText(advert.getCategory());
        holder.txtDate.setText(advert.getDate());

        try{
            holder.itemImage.setImageURI(Uri.parse(advert.getImagePath()));
        } catch (Exception e) {
            holder.itemImage.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        holder.itemView.setOnClickListener(v ->{
            Intent intent = new Intent(context, AdvertDetailsActivity.class);

            intent.putExtra("id", advert.getId());
            intent.putExtra("type", advert.getType());
            intent.putExtra("name", advert.getName());
            intent.putExtra("phone", advert.getPhone());
            intent.putExtra("category", advert.getCategory());
            intent.putExtra("description", advert.getDescription());
            intent.putExtra("location", advert.getLocation());
            intent.putExtra("image", advert.getImagePath());
            intent.putExtra("date", advert.getDate());

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount(){
        return advertList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        ImageView itemImage;
        TextView txtType, txtCategory, txtDate;

        public ViewHolder(@NonNull View itemView){
            super(itemView);
            itemImage = itemView.findViewById(R.id.itemImage);
            txtType = itemView.findViewById(R.id.txtType);
            txtCategory = itemView.findViewById(R.id.txtCategory);
            txtDate = itemView.findViewById(R.id.txtDate);
        }
    }
}